#!/bin/bash

sbatch run_strong_single.sh
sbatch run_strong_multi.sh
sbatch run_weak_single.sh
sbatch run_weak_multi.sh
